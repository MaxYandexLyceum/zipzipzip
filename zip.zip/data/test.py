import requests

a = requests.get("http://127.0.0.1:5000/api/v2/users")
print(a.json())
# всё ок
b = requests.get("http://127.0.0.1:5000/api/v2/user")
try:
    print(b.json())
except Exception as e:
    print(e)
# 404
params = {"id": 12, "surname": "ahaha", "name": "sdngsjdg", "age": 12,
          "position": "1", "speciality": "ffff", "address": "sdjnjdn"}
c = requests.post("http://127.0.0.1:5000/api/v2/users", json=params)
print(c.json())
# {'success': 'OK'}
params1 = {"surname": "ahaha", "name": "sdngsjdg", "age": 12,
           "position": "1", "speciality": "ffff", "address": "sdjnjdn"}
d = requests.post("http://127.0.0.1:5000/api/v2/users", json=params1)
print(d.json())
# {'message': 'Internal Server Error'}
# {'message': {'id': 'Missing required parameter in the JSON body or
# the post body or the query string'}}
d = requests.delete("http://127.0.0.1:5000/api/v2/users")
print(d.json())
# {'message': 'The method is not allowed for the requested URL.'}
d = requests.delete("http://127.0.0.1:5000/api/v2/users/12")
print(d.json())
# {'success': 'OK'}
