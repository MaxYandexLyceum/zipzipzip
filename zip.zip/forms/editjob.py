from flask_wtf import FlaskForm
from wtforms import PasswordField, StringField, TextAreaField, SubmitField, BooleanField
from wtforms.fields.html5 import EmailField
from wtforms.validators import DataRequired


class Editjob(FlaskForm):
    title = StringField('Job Title', validators=[DataRequired()])
    team_lider_id = StringField('Team Leader id', validators=[DataRequired()])
    work_size = StringField('Work size', validators=[DataRequired()])
    collaborators = StringField('collaborators', validators=[DataRequired()])
    hazard = StringField('Hazard category', validators=[DataRequired()])
    is_finished = BooleanField('Is job finished?')
    submit = SubmitField('Edit')
